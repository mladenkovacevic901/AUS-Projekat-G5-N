## Napomena o STA vrednosti

Specifikacija zahteva STA 148, ali sam primetio da MdbSim ne radi 
kako treba kad je vrednost veća od 127 — u naslovu pokaže -108 i 
komunikacija staje. Deluje kao da interno koristi signed tip pa 
dolazi do overflow-a.

Zato sam stavio STA 127 jer je to najveća vrednost koja radi. 
Modbus i inače dozvoljava adrese od 1 do 247 pa je ovo u redu. 
Moj kod u dComm-u radi sa celim opsegom, problem je samo u MdbSim-u.
